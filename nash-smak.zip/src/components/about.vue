<template>
  <section class="about" id="about">
      <div class="container">
        <div class="about-content">
          <div class="about-img"></div>
          <div class="about-info">
            <h2 class="about-title">
              Випікаємо, як для себе
            </h2>
            <p class="about-text">
              Тому що ми любимо свою справу, ретельно відбираємо інгредієнти і піклуємося, щоб вам смакувало! Тому що ми любимо свою справу, ретельно відбираємо інгредієнти і піклуємося, щоб вам смакувало!
            </p>
            <button class="btn about-btn">
              <router-link to="/">
                Більше про нас <img src="@/assets/img/arrow-right.svg" alt="Arrow">
              </router-link>
            </button>
          </div>
        </div>
      </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>