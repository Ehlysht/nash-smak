<template>
    <section class="newPage">
        <div class="container">
            <h2>
                Упс, Сторінка в розробці :) 
            </h2>
            <button class="btn">
                <router-link to="/">
                    Повернутись на головну
                </router-link>
            </button>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>